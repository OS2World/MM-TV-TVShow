/*
 * WarpVision fatsmemcpy
 *
 * based on xine project memcpy.c
 *
 * xine is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * xine is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * These are the MMX/MMX2/SSE optimized versions of memcpy
 *
 * This code was adapted from Linux Kernel sources by Nick Kurshev to
 * the mplayer program. (http://mplayer.sourceforge.net)
 *
 * Miguel Freitas split the #ifdefs into several specialized functions that
 * are benchmarked at runtime by xine. Some original comments from Nick
 * have been preserved documenting some MMX/SSE oddities.
 * Also added kernel memcpy function that seems faster than glibc one.
 *
 */

#include <stdio.h>

#include "common.h"
#include "dsputil.h"
#include "fastmemcpy.h"

void *(* fast_memcpy)(void *to, const void *from, size_t len);

void * _memcpy(void * to, const void * from, size_t len);
void * sse_memcpy(void * to, const void * from, size_t len);
void * mmx_memcpy(void * to, const void * from, size_t len);
void * mmx2_memcpy(void * to, const void * from, size_t len);

#ifndef FASTMEMCPY_TEST

int init_fast_memcpy(int mm_flgs)
{
    if (!mm_flgs & MM_MMX)
    { // no MMX
        fast_memcpy = _memcpy;
        av_log(NULL,AV_LOG_INFO ,"No accelerated fastmemcpy\n");
    }
    else if (mm_flgs & MM_MMXEXT)
    { // MMXEXT
        fast_memcpy = mmx2_memcpy;
        av_log(NULL,AV_LOG_INFO ,"Using MMXEXT for fastmemcpy\n");
    }
    else if (mm_flgs & MM_MMX)
    { // MMX
        fast_memcpy = mmx_memcpy;
        av_log(NULL,AV_LOG_INFO ,"Using MMX for fastmemcpy\n");
    }
    else if (mm_flgs & MM_SSE)
    { // SSE
        fast_memcpy = sse_memcpy;
        av_log(NULL,AV_LOG_INFO ,"Using SSE for fastmemcpy\n");
    }

    return 0;
}

#else

#define INCL_DOSMISC

#include <os2.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024*1024

int main()
{
    int x;
    int count = 500;
    char *src_buffer;
    char *dst_buffer;
    ULONG start_time, end_time;

    printf("size: %d, count: %d\nplease wait...\n", BUFFER_SIZE, count);

    src_buffer = malloc(BUFFER_SIZE);
    dst_buffer = malloc(BUFFER_SIZE);

    // no optimised memcpy
    fast_memcpy = _memcpy;

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &start_time, sizeof(ULONG));

    for(x = 0; x < count; x++)
    {
        fast_memcpy(dst_buffer, src_buffer, BUFFER_SIZE);
    }

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &end_time, sizeof(ULONG));

    printf("no optimised: %d ms\n", end_time - start_time);

    // mmx memcpy
    fast_memcpy = mmx_memcpy;

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &start_time, sizeof(ULONG));

    for(x = 0; x < count; x++)
    {
        fast_memcpy(dst_buffer, src_buffer, BUFFER_SIZE);
    }

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &end_time, sizeof(ULONG));

    printf("mmx: %d ms\n", end_time - start_time);

    // mmx2 memcpy
    fast_memcpy = mmx2_memcpy;

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &start_time, sizeof(ULONG));

    for(x = 0; x < count; x++)
    {
        fast_memcpy(dst_buffer, src_buffer, BUFFER_SIZE);
    }

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &end_time, sizeof(ULONG));

    printf("mmx2: %d ms\n", end_time - start_time);

    // sse memcpy
    fast_memcpy = sse_memcpy;

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &start_time, sizeof(ULONG));

    for(x = 0; x < count; x++)
    {
        fast_memcpy(dst_buffer, src_buffer, BUFFER_SIZE);
    }

    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &end_time, sizeof(ULONG));

    printf("sse: %d ms\n", end_time - start_time);
}


#endif
